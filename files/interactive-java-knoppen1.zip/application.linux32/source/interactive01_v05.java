import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.io.BufferedWriter; 
import java.io.FileWriter; 
import java.util.Queue; 
import java.util.LinkedList; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class interactive01_v05 extends PApplet {

/*

  interactive01
  v0.5 (29 july 2014)
  program displays images when controller sends a keysequence.
  intended for use in interactive display in the museum.
  naturalis / maarten schermer


  v0.5:
  \u2022 direct handling of keysequence replaced by a FiFo-stack of sequences. when clicking very fast,
    new keystrokes were processed before the previous keysequence had been properly handled, causing
    images to "hang" (ref: http://forum.processing.org/two/discussion/518/problem-calling-keypressed-/p1#Comment_1389).
    keysequences are now placed in a stack, which is read independently by the draw() method. 
  \u2022 moved variables closer to their initial point of use.
  
  v0.4:
  \u2022 ignores other keys than integers and Cr/Lf (arduino occasionally generates spaces).   
  
  v0.3:
  \u2022 application accepts keysequence ended by RETURN or ENTER. no longer uses keyReleased().
  \u2022 images have a double-digit keycode, starting from 00.
  \u2022 changed the order of the columns in the data file. order now is:
    [keycode][tab][image name][tab][common name][tab][scientific name]
    the last two fields are optional and currently unused, but intended for future logging.
  
  v0.2:
  \u2022 implemented noLoop() instead of draw(), now calls redraw() from keyPressed() and keyReleased().
  \u2022 moved startscreen() from draw() to keyReleased().
  \u2022 framerate and heartbeat() are now no longer used.


  format imagelist.txt
  file should contain  one image per line, each having four fields, separated by tabs (or rather, 
  fieldSeparator):
  1. key character (should correspond to controller's output) 
  2. image filename (only filename, no directory; file should exist in imageDir)
  3. common name (optional; unused)
  4. scientific name (optional; unused)
*/






// config
String setupFile = "setup.txt"; // config, overwrites values of variables below
char fieldSeparator = '\t'; // separator between var and val in setupFile

class ImageObject {

  PImage image;
  String fileName;
  String common;
  String scientific;
  String key;

  ImageObject(String tempCommon, String tempScientific, String tempImage, String tempKey) {
    fileName = tempImage;
    image = loadImage(imageDir+fileName);
    common = tempCommon;
    scientific = tempScientific;
    key = tempKey;
  }

  public String getKey() {
    return key;
  }

  public String getCommon() {
    return common;
  }

  public String getScientific() {
    return scientific;
  }

  public Boolean hasImage() {
    return !fileName.equals("");
  }

  public PImage getImage() {
    return image;
  }
}

public void setup() {
  try {
    prepareExitHandler();
    loadSetup();
    writelogline("application start");
    if (fullScreen) {
      screenWidth = displayWidth;
      screenHeight = displayHeight;
    }
    size(screenWidth, screenHeight);
    loadImages();
    startscreen();
    writelogline("finished setup");
  } 
  catch (Exception e) {
    writelogline("exception: "+e.toString());
  }
  noLoop();
}

private void prepareExitHandler() {
  Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
    public void run () {
      writelogline("application stop");
    }
  }));
}


// configurable variables & defaults
String programName = "generic program name"; // used while logging
String programLocation = "generic program location"; // unused (for now)
String dataFile = "imagelist.txt"; // file with images and corresponding keys
String imageDir = "images/"; // directory containing the images
String startscreenImage="00";
String startImage = imageDir+"achtergrond.bmp"; // image for startscreen
int screenWidth = 800;
int screenHeight = 600;
Boolean fullScreen = true; // run app fullscreen (still needs to run as 'present') 
//int framerate = 60; // fps
String logFile = "";
//int heartbeatInterval = 10; // seconds (approx) between logging 'alive'-signals
Boolean logUserInteraction = false; // log all user pressed keys (including unassigned ones)
Boolean unknownKeyToStartscreen = false; // an unknown keysequence reloads the startscreen 

public void loadSetup() {
  String lines[] = loadStrings(setupFile);
  for (int i = 0; i < lines.length; i++) {
    if (lines[i].toString().length()>0) {
      
      String[] properties = split(lines[i], fieldSeparator);
      if (properties[0].equals("programName")) {
        programName = properties[1];
      } 
      else
      if (properties[0].equals("programLocation")) {
        programLocation = properties[1];
      } 
      else
      if (properties[0].equals("dataFile")) {
        dataFile = properties[1];
      } 
      else
      if (properties[0].equals("logFile")) {
        logFile = properties[1];
      } 
      else
      if (properties[0].equals("imageDir")) {
        imageDir = properties[1];
        if (!String.valueOf(imageDir.charAt(imageDir.length()-1)).equals("/")) {
          imageDir=imageDir+'/';
        }
      } 
      else
      if (properties[0].equals("screenWidth")) {
        screenWidth = PApplet.parseInt(properties[1]);
      } 
      else
      if (properties[0].equals("screenHeight")) {
        screenHeight = PApplet.parseInt(properties[1]);
      } 
      else
      if (properties[0].equals("fullScreen")) {
        fullScreen = PApplet.parseBoolean(properties[1]);
      }
      else
      if (properties[0].equals("logUserInteraction")) {
        logUserInteraction = PApplet.parseBoolean(properties[1]);
      }
      else
      if (properties[0].equals("startscreenImage")) {
        startscreenImage = properties[1];
      }
      else
      if (properties[0].equals("unknownKeyToStartscreen")) {
        unknownKeyToStartscreen = PApplet.parseBoolean(properties[1]);
      }
    }
  }
}

public void loadImages() {
  String names[] = loadStrings(dataFile);
  Boolean comment=false;
  for (int i = 0; i < names.length; i++)
  {
    if (trim(names[i].toString()).equals("/*"))
      comment=true;
    if (trim(names[i].toString()).equals("*/"))
      comment=false;

    if (names[i].toString().length()>0 && !comment)
    {
      String[] properties = split(names[i], fieldSeparator);
      if(properties.length>=2)
      {
        String common = (properties.length>=3 ? properties[2] : "");
        String scientific = (properties.length>=4 ? properties[3] : "");

        if (fileExists(imageDir+properties[1]))
        {
          imageObjects.add(new ImageObject(common, scientific, properties[1], properties[0]));
          if (properties[0].equals(startscreenImage))
          {
            startImage = imageDir+properties[1];
          }
        }
        else
        {
           writelogline("image does not exist: "+imageDir+properties[1]);
        }
      }
    }
  }
}

public void startscreen() {
  PImage startScreen = loadImage(startImage);
  image(startScreen, 0, 0, screenWidth, screenHeight);
}


String keysequence="";
Queue<String> stack = new LinkedList<String>();

public void keyPressed() {

  //logKey(key);

  if (key==RETURN || key==ENTER)
  {
    stack.add(keysequence);
    keysequence="";
    redraw();
  }
  else
  if (isInteger(key))
  {
    keysequence=keysequence+str(key);
  }
  else
  { 
    //our arduino sometimes generates two spaces after each 00, 
    //don't want to flood the log file
    //writelogline("unpressable key: \""+key+"\"");
  }  

}

ArrayList<ImageObject> imageObjects = new ArrayList<ImageObject>();

public void draw() {

  Boolean foundImage;
  String sequence="";

  try {
  
    while (sequence.equals("")) {
      
      sequence = stack.remove();
    
      try {
            foundImage=false;
            if (logUserInteraction) { 
              writelogline("user pressed \""+sequence+"\"");
            }
            for (int i = 0; i < imageObjects.size(); i++) {
              ImageObject someImage = imageObjects.get(i);
              if (someImage.getKey().equals(sequence)) {
                image(someImage.getImage(), 0, 0, screenWidth, screenHeight);
                foundImage=someImage.hasImage();
              }
            }
            if (!foundImage)
            { 
              writelogline("\""+sequence+"\": unassigned keysequence");
              if (unknownKeyToStartscreen)
              {
                startscreen();
              }
            }
            sequence="";
      } 
      catch (Exception e) {
        writelogline("exception: "+e.toString());
      }
    } 
  }
  catch (Exception e) {
    // stack is empty
  }
}

public Boolean fileExists(String filename)
{
  File f = new File(dataPath(filename));
  return f.exists();
}

public Boolean isInteger(char s) {
  try {
    Integer.parseInt(str(s));
    return true;
  }
  catch (Exception e) {
    return false;
  }
}

public void createFile(File f) {
  File parentDir = f.getParentFile();
  try {
    parentDir.mkdirs(); 
    f.createNewFile();
  } 
  catch (Exception e) {
    //println(e);
    //e.printStackTrace();
  }
} 

public void writelogline(String line) {
  if (!logFile.equals("")) {
    File f = new File(dataPath(logFile));
    if (!f.exists()) {
      createFile(f);
    }
    try {
      String timestamp=nf(year(), 4)+'-'+nf(month(), 2)+'-'+nf(day(), 2)+' '+nf(hour(), 2)+':'+nf(minute(), 2)+':'+nf(second(), 2);
      PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(f, true)));
      out.println(programName+" - "+timestamp+" - "+line);
      out.close();
    } 
    catch (IOException e) {
      //println(e);
      //e.printStackTrace();
    }
  }
}

public void heartbeat() {
  /*
  if ((iterations/frameRate)>heartbeatInterval) {
    writelogline("alive");
    iterations=0;
  } else {
    iterations++;
  }
  */
}

public void logKey(char key) {
  if (key==RETURN)
  {
    writelogline("> RETURN");
  }
  else
  if (key==ENTER)
  {
    writelogline("> ENTER");
  }
  else
  {
    writelogline("> "+str(key));
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--hide-stop", "interactive01_v05" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
